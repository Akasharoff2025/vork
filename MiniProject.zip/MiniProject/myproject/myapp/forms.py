from django import forms
from .models import User, Company
from django.core.exceptions import ValidationError

# ------------------------------
# User Registration Form
# ------------------------------
class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['full_name', 'username', 'email', 'phone', 'dob', 'address', 'password']

    # Validate that passwords match
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password != confirm_password:
            raise ValidationError("Passwords do not match")
        return cleaned_data


# ------------------------------
# Company Registration Form
# ------------------------------
class CompanyRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Company
        fields = [
            "company_name", "username", "email", "phone", "website",
            "address", "tax_id", "business_type", "num_employees", "password"
        ]

    # Validate that passwords match
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        if password != confirm_password:
            raise ValidationError("Passwords do not match!")
        return cleaned_data
    