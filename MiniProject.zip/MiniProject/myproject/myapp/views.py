from django.shortcuts import render

# Create your views here.
def index(request):
                  return render(request,"index.html")
def admin_login(request):
                  return render(request, "admin_login.html")
def user_login(request):
                  return render(request,"user_login.html")
def company_login(request):
                  return render(request,"company_login.html")
def register(request):
                   return render(request, "register.html")
def login_option(request):
                  return render(request, "login_option.html")
def user_registration(request):
                  return render(request, "user_registration.html")
def company_registration(request):
                  return render(request, "company_registration.html")
