from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .forms import UserRegistrationForm, CompanyRegistrationForm
from .models import Company  
from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, get_object_or_404
from .models import Company



# Public pages
def index(request):
    return render(request, "index.html")

def admin_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            if user.is_superuser:
                login(request, user)
                return redirect('admin_dashboard')  # Redirect to your admin dashboard
            else:
                messages.error(request, "You are not an admin!")
        else:
            messages.error(request, "Invalid username or password!")
    
    return render(request, "admin_login.html")


def login_option(request):
    return render(request, "login_option.html")


# Company login view
def company_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            company = Company.objects.get(username=username)
        except Company.DoesNotExist:
            return render(request, 'company_login.html', {'error': 'Invalid credentials'})

        # Check hashed password
        if check_password(password, company.password):
            # Store company ID in session
            request.session['company_id'] = company.id
            return redirect('company_homepage')
        else:
            return render(request, 'company_login.html', {'error': 'Invalid credentials'})
    return render(request, 'company_login.html')



def company_registration(request):
    if request.method == "POST":
        form = CompanyRegistrationForm(request.POST)
        if form.is_valid():
            company = form.save(commit=False)
            # Hash password manually since Company is not AbstractBaseUser
            company.password = make_password(form.cleaned_data['password'])
            company.save()
            return redirect('company_login')
    else:
        form = CompanyRegistrationForm()
    
    return render(request, "company_registration.html", {'form': form})


def company_homepage(request):
    company_id = request.session.get('company_id')
    if not company_id:
        return redirect('company_login')

    company = Company.objects.get(id=company_id)
    return render(request, 'company_homepage.html', {'company': company})





# User Authentication
def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('user_homepage')
        else:
            return render(request, 'user_login.html', {'error': 'Invalid credentials'})
    return render(request, 'user_login.html')


@login_required(login_url='user_login')
def user_homepage(request):
    return render(request, 'user_homepage.html')


def user_logout(request):
    logout(request)
    return redirect('user_login')


# User registration
def user_registration(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return redirect('user_login')
    else:
        form = UserRegistrationForm()
    
    return render(request, "user_registration.html", {'form': form})


# Contact page
def contact(request):
    return render(request, 'contact.html')
from django.shortcuts import render

def post_jobs(request):
    return render(request, "post_jobs.html")

def manage_jobs(request):
    return render(request, "manage_jobs.html")
def applicants(request):
    return render(request, "applicants.html")

def admin_dashboard(request):
    if not request.user.is_authenticated or not request.user.is_superuser:
        return redirect("admin_login")  # restrict access
    return render(request, "admin_dashboard.html")

def view_company(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    return render(request, 'view_company.html', {'company': company})