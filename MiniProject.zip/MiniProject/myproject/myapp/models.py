from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

# ------------------------------
# Custom User Manager
# ------------------------------
class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Users must have an email address')
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        return self.create_user(username, email, password, **extra_fields)

# ------------------------------
# Custom User Model
# ------------------------------
class User(AbstractBaseUser, PermissionsMixin):
    full_name = models.CharField(max_length=100)
    username = models.CharField(max_length=50, unique=True)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    dob = models.DateField()
    address = models.CharField(max_length=255, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'full_name', 'phone', 'dob']

    def __str__(self):
        return self.username

# ------------------------------
# Company Model
# ------------------------------
class Company(models.Model):
    company_name = models.CharField(max_length=255)
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20)
    website = models.URLField(blank=True, null=True)
    address = models.TextField()
    tax_id = models.CharField(max_length=100)
    business_type = models.CharField(
        max_length=50,
        choices=[
            ('tech', 'Technology'),
            ('retail', 'Retail'),
            ('services', 'Services'),
            ('manufacturing', 'Manufacturing'),
            ('other', 'Other'),
        ]
    )
    num_employees = models.PositiveIntegerField(blank=True, null=True)
    password = models.CharField(max_length=128)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.company_name

# ------------------------------
# Job Model
# ------------------------------
class Job(models.Model):
    CATEGORY_CHOICES = [
        ('Hospitality', 'Hospitality'),
        ('Childcare', 'Childcare'),
        ('Retail', 'Retail'),
        ('Marketing', 'Marketing'),
        ('Design', 'Design'),
        ('Administration', 'Administration'),
        ('Other', 'Other'),
    ]

    JOB_TYPE_CHOICES = [
        ('In-Person', 'In-Person'),
        ('Remote', 'Remote'),
        ('Hybrid', 'Hybrid'),
    ]

    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='jobs')
    title = models.CharField(max_length=100)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    location = models.CharField(max_length=100)
    job_type = models.CharField(max_length=20, choices=JOB_TYPE_CHOICES)
    pay_rate = models.DecimalField(max_digits=10, decimal_places=2)
    hours_per_week = models.PositiveIntegerField()
    responsibilities = models.TextField(max_length=1000)
    qualifications = models.TextField(max_length=1000)
    benefits = models.TextField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.company.company_name})"

# ------------------------------
# Application Model
# ------------------------------
class Application(models.Model):
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='applications')
    applicant = models.ForeignKey(User, on_delete=models.CASCADE, related_name='applications')
    resume = models.FileField(upload_to='resumes/')
    applied_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.applicant.username} applied for {self.job.title}"
