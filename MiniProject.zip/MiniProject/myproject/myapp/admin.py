from django.contrib import admin
from .models import User, Company, Job, Application

# -----------------------------
# User Admin
# -----------------------------
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'full_name', 'is_active', 'created_at')
    search_fields = ('username', 'email', 'full_name')

# -----------------------------
# Company Admin
# -----------------------------
@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'username', 'email', 'phone', 'business_type', 'num_employees', 'created_at')
    search_fields = ('company_name', 'username', 'email')

# -----------------------------
# Job Admin
# -----------------------------
@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'company', 'location', 'posted_at')  # use 'posted_at', not 'created_at'
    search_fields = ('title', 'company__company_name')

# -----------------------------
# Application Admin
# -----------------------------
@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('applicant', 'job', 'applied_at')  # use 'applicant', not 'user'
    search_fields = ('applicant__username', 'job__title')
