from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name="index"),           
    path('company_login/', views.company_login, name="company_login"), 
    path('login/', views.login_option, name='login_option'),
    path('user_registration/', views.user_registration, name='user_registration'),
    path('company_registration/', views.company_registration, name='company_registration'),
    path('contact/', views.contact, name='contact'),
    path('user_login/', views.user_login, name='user_login'),
    path('user_homepage/', views.user_homepage, name='user_homepage'),
    path('logout/', views.user_logout, name='user_logout'), 
    path('company_homepage/', views.company_homepage, name='company_homepage'),  
    path('post_jobs/', views.post_jobs, name="post_jobs"),  
    path('manage_jobs/', views.manage_jobs, name="manage_jobs"),  
    path('applicants/', views.applicants, name="applicants"),    
    path("admin_dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path('admin_login/', views.admin_login, name='admin_login'),
    path('company/<int:company_id>/', views.view_company, name='view_company'),
     
]